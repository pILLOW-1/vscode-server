# Simple Browser

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.

Provides a very basic browser preview using an iframe embedded in a [webviewW](). This extension is primarily meant to be used by other extensions for showing simple web content.
